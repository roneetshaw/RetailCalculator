// INSPIRED BY SEB KAY'S 'SIGN UP FORM'
// https://dribbble.com/shots/1776663-Purple-Sign-Up-Form
// https://dribbble.com/shots/1779149--Free-PSD-Purple-Sign-Up-Form-Payment-Details

// DO YOU HAVE A SPARE DRIBBBLE INVITE? I'D	APPRECIATE IT!
// dribbble.com/josec
A Pen created at CodePen.io. You can find this one at https://codepen.io/pollardld/pen/BaADg.

 Accordion built using all CSS. The :target css selector is used.